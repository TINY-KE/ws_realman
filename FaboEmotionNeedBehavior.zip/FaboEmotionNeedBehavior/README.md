# 真实机械臂
+ 启动真实机械臂
```bash
roslaunch arm_control arm_control.launch
```

+ 发布机械臂的关节角度
rostopic pub /rm_driver/MoveJ_Cmd



# 仿真机械臂
+ gazebo和moveit
roslaunch rm_gazebo arm_65_bringup_moveit.launch

+ 接收并转发
rosrun arm_control pub_joints.py

+ 发布机械臂的关节角度
rostopic pub /joint_target std_msgs/Float64MultiArray "data: [1.5, -0.7, 0.5, -0.0, 0.2, -0.]" --once
rostopic pub /joint_target std_msgs/Float64MultiArray "data: [-1.5, 0.1, 0.1, -0.0, 0.2, -0.]" --once


# 仿真机械臂+底盘
+ 仿真环境  注意将机械臂加入了group中（要source当前工作空间，因为底盘的base_link改名了）
roslaunch rm_gazebo arm_65_bringup_moveit.launch

+ 底盘键盘
ROS_NAMESPACE=/2 rosrun turtlebot3_teleop turtlebot3_teleop_key

+ 运行cartographer（要换到cartographer的工作空间）
roslaunch cartographer_ros turtlebot3_2d.launch

+ 实机视点规划
rosrun view_planning_real view_plannin

+ 
rostopic pub /object_centor geometry_msgs/PointStamped "header:
  seq: 0
  stamp:
    secs: 0
    nsecs: 0
  frame_id: ''
point:
  x: 1.0
  y: 1.0
  z: 0.0"

rostopic pub /stop_loop std_msgs/Bool  "data: false" 

