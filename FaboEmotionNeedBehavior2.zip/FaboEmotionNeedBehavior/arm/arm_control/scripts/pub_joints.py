#!/usr/bin/env python

import rospy
from moveit_commander import MoveGroupCommander
from std_msgs.msg import Float64MultiArray

class JointTargetController:
    def __init__(self):
        # 初始化 ROS 节点
        rospy.init_node('joint_target_controller', anonymous=True)
        
        # 初始化 MoveIt 的 MoveGroupCommander
        self.group = MoveGroupCommander("arm")  # 替换 "arm" 为你的关节组名称
        
        # 订阅目标关节值的话题
        self.subscriber = rospy.Subscriber('/joint_target', Float64MultiArray, self.joint_target_callback)
        
        rospy.loginfo("Joint Target Controller initialized and listening to /joint_target topic.")
        rospy.loginfo("用以下格式发布机械臂的关节角度: \n rostopic pub /joint_target std_msgs/Float64MultiArray \"data: [-1.5, 0.3, 0.1, -0.0, 0.2, -0.]\" --once  \n")


    def joint_target_callback(self, msg):
        """
        回调函数：接收六维向量并设置关节目标值
        """
        try:
            # 获取目标关节值（六维向量）
            joint_targets = msg.data  # 例如 [1.0, 0.5, 0.0, -0.5, 0.2, -1.0]

            # 检查是否是六维向量
            if len(joint_targets) != 6:
                rospy.logwarn("Received joint target does not have 6 dimensions. Ignoring this message.")
                return

            # 设置目标关节值
            self.group.set_joint_value_target(joint_targets)

            # 执行运动
            success = self.group.go(wait=True)
            if success:
                rospy.loginfo("Robot successfully moved to the target joint positions: {}".format(joint_targets))
            else:
                rospy.logwarn("Failed to move the robot to the target joint positions.")

        except Exception as e:
            rospy.logerr("Error while processing joint target: {}".format(e))

    def spin(self):
        # 保持节点运行
        rospy.spin()


if __name__ == '__main__':

    try:
        controller = JointTargetController()
        controller.spin()
    except rospy.ROSInterruptException:
        pass



# import rospy
# from std_msgs.msg import Float64MultiArray

# def joint_target_publisher():
#     rospy.init_node('joint_target_publisher', anonymous=True)
#     pub = rospy.Publisher('/joint_target', Float64MultiArray, queue_size=10)
#     rate = rospy.Rate(1)  # 1 Hz

#     while not rospy.is_shutdown():
#         # 定义六维向量
#         joint_targets = Float64MultiArray()
#         joint_targets.data = [1.0, 0.5, 0.0, -0.5, 0.2, -1.0]  # 替换为你的目标值

#         # 发布消息
#         pub.publish(joint_targets)
#         rospy.loginfo(f"Published joint targets: {joint_targets.data}")

#         rate.sleep()

# if __name__ == '__main__':
#     rospy.loginfo("Publish joint targets: \n rostopic pub /joint_target std_msgs/Float64MultiArray \"data: [0.5, 0.3, 0.1, -0.2, 0.0, -0.8]\" --once  \n")
#     try:
#         joint_target_publisher()
#     except rospy.ROSInterruptException:
#         pass